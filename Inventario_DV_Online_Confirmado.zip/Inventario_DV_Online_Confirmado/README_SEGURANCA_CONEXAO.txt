INVENTÁRIO DV — CONFERÊNCIA SOMENTE COM CONFIRMAÇÃO DO BANCO

OBJETIVO
Esta versão NÃO possui fila offline. Uma leitura só aparece como conferida quando a chamada de registro ao Supabase retorna uma resposta definitiva.

COMPORTAMENTO
1. Sem internet detectada pelo aparelho:
   - a câmera de conferência é bloqueada/fechada;
   - a entrada manual fica bloqueada;
   - aparece o aviso SEM INTERNET — conferência bloqueada;
   - nenhum QR é aceito como conferido.

2. Aparelho indica online, mas o Supabase/banco não responde:
   - a leitura NÃO entra em Últimas leituras;
   - não aparece VOLUME CONFERIDO;
   - aparece LEITURA NÃO CONFIRMADA;
   - o conferente deve estabilizar a conexão e ler o volume novamente.

3. Banco responde com sucesso:
   - somente então a leitura é mostrada como conferida/divergente/duplicada conforme a resposta do servidor.

4. Se a biblioteca do Supabase não carregar em uma instalação configurada para produção:
   - o aplicativo NÃO cai em modo demonstração;
   - o login fica bloqueado e informa que a conexão com o banco está indisponível.

IMPORTANTE SOBRE QUEDA NO EXATO MOMENTO DA RESPOSTA
Em qualquer sistema online pode ocorrer o caso raro de o banco gravar a leitura e a resposta não chegar ao aparelho por uma queda instantânea da rede. Nesta versão o aparelho NÃO afirma sucesso sem receber a confirmação. Ao reler o mesmo volume depois que a conexão voltar, a proteção de duplicidade do servidor indicará que ele já foi conferido caso a primeira gravação tenha chegado ao banco.

PUBLICAÇÃO
1. Faça backup do pacote atualmente publicado.
2. Publique o conteúdo desta pasta na raiz do Cloudflare Pages/ambiente usado em produção.
3. Confirme que index.html, app-config.js, service-worker.js, manifest.webmanifest, _headers e assets/ ficaram na raiz.
4. Após o deploy, abra a aplicação com internet e faça uma atualização completa.
5. Em cada coletor/PWA, abra a aplicação com internet para que o Service Worker v6 seja instalado. Se necessário, feche e abra a PWA novamente.

TESTE OBRIGATÓRIO ANTES DE LIBERAR PARA TODOS
A. Com internet: leia um volume de teste e confirme que o comportamento normal permanece igual.
B. Desligue Wi-Fi e dados móveis: a câmera deve ser bloqueada/fechada, a entrada manual deve ficar desabilitada e deve aparecer SEM INTERNET.
C. Religue a internet: os controles devem ser liberados novamente.
D. Para simular falha do servidor, teste em homologação bloqueando temporariamente o acesso ao Supabase/rede. O resultado deve ser LEITURA NÃO CONFIRMADA e não deve entrar em Últimas leituras.

NENHUM SQL NOVO É NECESSÁRIO PARA ESTA ALTERAÇÃO.
